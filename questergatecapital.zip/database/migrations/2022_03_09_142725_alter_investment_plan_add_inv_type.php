<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterInvestmentPlanAddInvType extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('investment_plan', function (Blueprint $table) {
            $table->string('days')->nullable();
            $table->enum('inv_type',['flex', 'fixed'])->default('fixed');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('investment_plan', function (Blueprint $table) {
            //
        });
    }
}
